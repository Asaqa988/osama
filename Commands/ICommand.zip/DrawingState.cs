namespace DrawingApp.Commands
{
    /// <summary>
    /// Represents the current state of the drawing environment.
    /// </summary>
    public class DrawingState
    {
    }
}
